from os import system, name

def separar (string, lista, palabra, letra, contador):
    """se busca un especio"""
    if letra < contador:
        try:
            numero = int(string[letra])
        except:
            numero = False
        if string [letra] != " ":
            return separar (string,lista, palabra + str (string[letra]), letra + 1, contador);
        else:
            return separar (string,lista + [palabra], "" , letra + 1, contador);
    elif letra ==  contador and palabra != "":
        """originalmente no me salte un parametro a pasar aqui, pero lo tome como
        un error menor y corregible (pues fue por despistada), de no ser el caso
        pues... tener en cuenta el cambio"""        
        return separar (string,lista + [palabra], "" , letra + 1, contador);
    else:
        return lista


"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
def limpiarPantalla ():
    # Windows 
    if name == 'nt': 
        _ = system('cls') 
  
    # MAC y Linux
    else: 
        _ = system('clear') 

"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
def dic (lista):
    if lista ==[]:
        return {}
    resultado = {}
    while lista != []:
        resultado[lista[0]]=int(lista[1]);
        lista = lista[2:]
    return resultado


"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""

def guardar(colores, diccionario):
    nueva = ""
    while colores != []:
        try:
            diccionario[colores[0]]= diccionario[colores[0]]+0;
            nueva += str(colores[0])
            nueva += " "
            nueva += str(diccionario[colores[0]])
            nueva += " "
            colores = colores[1:]
        except:
            colores = colores[1:]
    
        
    pinturas = open("pinturas.txt", "w")
    pinturas.write (nueva)
    pinturas.close()


"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
def error(colores,funcion,datos):
    print("\nNo se encuentra en la base\n \n")
    accionesdoc (colores, funcion, datos);
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
    
def accionesdoc (colores, funcion, datos):
    #print(datos)
    buscar = 0
    while (funcion != "S" and funcion != "s" and buscar != 8):
        if funcion == "C" or funcion == "c":
            print ("\nSeleccione el color a consultar:\n1 = azul\n2 = rojo\n3 = blanco\n4 = amarillo\n5 = negro\n6 = verde\n7 = cafe\n8 = salir\n* = todos")
            buscar = input()
            try:
                buscar = int(buscar)
            except:
                pass;
        
            if buscar == 1:
                try:
                    print("\nCantidad:",datos["azul"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 2:
                try:
                    print("\nCantidad:",datos["rojo"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 3:
                try:
                    print("\nCantidad:",datos["blanco"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 4:
                try:
                    print("\nCantidad:",datos["amarillo"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 5:
                try:
                    print("\nCantidad:",datos["negro"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 6:
                try:
                    print("\nCantidad:",datos["verde"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == 7:
                try:
                    print("\nCantidad:",datos["cafe"])
                    accionesdoc (colores, funcion, datos);
                except:
                    error(colores,funcion,datos);
            elif buscar == "*":
                print(datos);
            
        if funcion == "I" or funcion == "i":
            print ("\nSeleccione el color a agregar:\n1 = azul\n2 = rojo\n3 = blanco\n4 = amarillo\n5 = negro\n6 = verde\n7 = cafe\n8 = salir")
            buscar = int(input())
            
            if (buscar > 0 and buscar < 8):
                print ("Digite la cantidad a agregar:")
                agregar = int(input())
        
            if buscar == 1:
                try:
                    datos["azul"] = datos["azul"]+agregar
               
                except:
                    datos["azul"] = agregar
               
            elif buscar == 2:
                try:
                    datos["rojo"] = datos["rojo"]+agregar
                
                except:
                    datos["rojo"] = agregar
               
            elif buscar == 3:
                try:
                    datos["blanco"] = datos["blanco"]+agregar
                
                except:
                    datos["blanco"] = agregar
                
            elif buscar == 4:
                try:
                    datos["amarillo"] = int(datos["amarillo"])+agregar
               
                except:
                    datos["amarillo"] = agregar
               
            elif buscar == 5:
                try:
                    datos["negro"] = datos["negro"]+agregar
                
                except:
                    datos["negro"] = agregar
              
            elif buscar == 6:
                try:
                    datos["verde"] = datos["verde"]+agregar
                
                except:
                    datos["verde"] = agregar
                
            elif buscar == 7:
                try:
                    datos["cafe"] = datos["cafe"]+agregar
               
                except:
                    datos["cafe"] = agregar
        
        if funcion == "E" or funcion == "e":
            print ("\nSeleccione el color a eliminar:\n1 = azul\n2 = rojo\n3 = blanco\n4 = amarillo\n5 = negro\n6 = verde\n7 = cafe\n8 = salir")
            buscar = int(input())

            if (buscar > 0 and buscar < 8):
                print ("Digite la cantidad a eliminar:")
                agregar = int(input())
        
            if buscar == 1:
                try:
                    datos["azul"] = datos["azul"]-agregar
                    if datos["azul"]==0:
                        del datos["azul"]
                
                except:
                    error(colores,funcion,datos);
            elif buscar == 2:
                try:
                    datos["rojo"] = datos["rojo"]-agregar
                    if datos["rojo"]==0:
                        del datos["rojo"]                
                
                except:
                    error(colores,funcion,datos);
            elif buscar == 3:
                try:
                    datos["blanco"] = datos["blanco"]-agregar
                    if datos["blanco"]==0:
                        del datos["blanco"]                
                
                except:
                    error(colores,funcion,datos);
            elif buscar == 4:
                try:
                    datos["amarillo"] = int(datos["amarillo"])-agregar
                    if datos["amarillo"]==0:
                        del datos["amarillo"]
               
                except:
                    error(colores,funcion,datos);
            elif buscar == 5:
                try:
                    datos["negro"] = datos["negro"]-agregar
                    if datos["negro"]==0:
                        del datos["negro"]                
                
                except:
                    error(colores,funcion,datos);
            elif buscar == 6:
                try:
                    datos["verde"] = datos["verde"]-agregar
                    if datos["verde"]==0:
                        del datos["verde"]                
              
                except:
                    error(colores,funcion,datos);
            elif buscar == 7:
                try:
                    datos["cafe"] = datos["cafe"]-agregar
                    if datos["cafe"]==0:
                        del datos["cafe"]                
                except:
                    error(colores,funcion,datos);                                
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""                                                
                
        

def principal (colores, diccionario):                
    funcion = ""

    while (funcion != "S" and funcion != "s"):
        limpiarPantalla()
        print("Seleccione una operacion:\nC = Consultar\nI = Insertar \nE = Eliminar\nS = Salir")
        funcion  = str(input())
        accionesdoc(colores, funcion, diccionario);
    
    guardar(colores, diccionario);
    

        
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""
"""_______________________________________________________________________________________________________________________________________"""

import sys
"""Valores por defecto"""
global pinturas
global colores

colores  = ["azul", "rojo", "blanco", "amarillo", "negro", "verde", "café"]
pinturas = open("pinturas.txt", "r")
pinturas = pinturas.read()

valores = (separar (pinturas, [], "", 0, len(pinturas)));
diccionario = dic(valores);

principal(colores, diccionario);

