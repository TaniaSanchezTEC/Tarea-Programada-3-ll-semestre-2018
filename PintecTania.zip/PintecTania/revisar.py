#Ejercicio 3

def generarListas (numero):
    lista = []
    while numero != 0:
        digito = numero % 10
        numero = numero //10
        lista.append(digito)
    return lista


#print(generarListas(123456))
"""_____________________________________________________________________________________________________________________________________________________________"""

def operando (primero, segundo, simbolo):
    resultado = []
    acarreo = 0
    prestado = 0
    while (len(primero)!=0 or len(segundo)!=0):
        try:
            uno = (primero[0])-prestado
            prestado = 0
        except:
            uno = 0
        try:
            dos = segundo[0]
        except:
            dos = 0
        """este pedazo no estaba en el codigo original"""
        primero = primero[1:]
        segundo = segundo[1:]

        if simbolo == "+":
            suma = uno + dos + acarreo
            digito = suma % 10
            acarreo = suma // 10
            resultado.append (digito)

        if simbolo == "-":
            if (uno < dos):
                uno = 10 + uno
                prestado = 1
            resta = uno - dos
            #resultado. append (resta) Este es el original
            resultado. append (resta)
    return (resultado)

"""_____________________________________________________________________________________________________________________________________________________________"""

def enteros_largos_imprimir (num1, num2, simbolo):
    
    primero = generarListas (abs(num1))
    segundo = generarListas (abs(num2))

    if num1 > 0 and num2 > 0:
        
        if (num1 < num2 and simbolo == "-"):
            resultado = operando(segundo, primero, simbolo)+["-"]
            
        else:
            resultado = operando(primero, segundo, simbolo)
            
    if (num1 > 0 and num2 < 0 and simbolo == "-"):
        resultado = operando(primero, segundo, "+")
        
    if (num1 < 0 and num2 > 0 and simbolo == "-"):
        resultado = operando(primero, segundo, "+")+["-"]
        
    if (num1 > 0 and num2 < 0 and simbolo == "+"):
        #resultado = operando(primero, segundo, "-")
        resultado = operando(segundo, primero, "-")+["-"]
        
    if (num1 < 0 and num2 > 0 and simbolo == "+"):
        resultado = operando(segundo, primero, "-")

    primero.reverse()
    segundo.reverse()
    resultado.reverse()

    print("Lista del primer numero:")
    print(primero)

    print("Lista del segundo numero:")
    print(segundo)

    print("Lista del numero resultante:")
    print(resultado)

print (enteros_largos_imprimir (4888,-40000, "+"))
